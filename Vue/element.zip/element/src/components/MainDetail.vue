<template>
  <div class='main-detail'>{{ message }}</div>
</template>

<script>
  export default {
    name: 'MainDetail',
    data () {
      message : '这是默认首页'
    }
  }
</script>
export interface State {
  movieList: []
}
//约束一个对象必须拥有哪些属性或方法
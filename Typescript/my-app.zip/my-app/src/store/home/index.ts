import { State } from '@/store/interface';

const getters = {
  
}

const state: State = {
  movieList: []
}

const mutations = {

}

const actions = {
  // api 前后端的分离点
  // commit mutations
}

export default {
  state,
  getters,
  mutations,
  actions
}
<template>
  <div class="login">登录页面</div>
</template>

<script>
export default {
  name: 'Login'
}
</script>

<style>

</style>

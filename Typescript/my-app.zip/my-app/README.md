- .ts
  typescript是js的超集
  typescript会编译成js
  可以跟写java一样
  .ts -> webpack loader -> babel -> js
  大型项目，可以有效的较少bug 60%
  更好的多人协作

- 将弱类型的js 变成 静态类型的typescript
  错误在编译阶段就解决了
  let a:string = '2';
  加一个类型声明 在比较重要的场合

- interface 声明自定义的类型 接口 
  多出20% 的代码 有了类型检验，代码更可靠
  有利于合作